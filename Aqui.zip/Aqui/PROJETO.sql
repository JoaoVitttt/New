CREATE TABLE usuario(
    Id_usuario integer NOT NULL GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    Nome_usuario varchar(50) NOT NULL,
	Senha_usuario varchar(8) NOT NULL
	);
	
insert into usuario (Nome_usuario, Senha_usuario) values ('xmp', '12345678');
insert into usuario (Nome_usuario, Senha_usuario) values ('https', '87654321');

SELECT * FROM usuario;


CREATE TABLE conta(
    Id_usuario integer NOT NULL GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    saldo_conta NUMERIC,
	credito_conta NUMERIC 
	);
	
insert into conta (saldo_conta, credito_conta) values ('150', '500');

SELECT * FROM conta;

UPDATE conta SET saldo_conta = saldo_conta + 100 WHERE Id_usuario = 1;


MySQL

SELECT * FROM banco.usuario;
alter table usuario add credito_conta NUMERIC;
insert into usuario (nome_usuario, senha_usuario, saldo_conta, credito_conta) values ('xmp', '12345678', '150', '500');

update usuario set saldo_conta = saldo_conta - 40 where id_usuario = 1;