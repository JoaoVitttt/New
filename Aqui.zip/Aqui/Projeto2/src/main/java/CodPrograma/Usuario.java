package CodPrograma;

/**
 *
 * @author Adm
 */
public class Usuario {

    private int Id_usuario;
    private String Nome_usuario, Senha_usuario;
    private double saldo_conta = 0.0;
    private double credito_conta = 500.0;

    /**
     * @return the Id_usuario
     */
    public int getId_usuario() {
        return Id_usuario;
    }

    /**
     * @param Id_usuario the Id_usuario to set
     */
    public void setId_usuario(int Id_usuario) {
        this.Id_usuario = Id_usuario;
    }

    /**
     * @return the Nome_usuario
     */
    public String getNome_usuario() {
        return Nome_usuario;
    }

    /**
     * @param Nome_usuario the Nome_usuario to set
     */
    public void setNome_usuario(String Nome_usuario) {
        this.Nome_usuario = Nome_usuario;
    }

    /**
     * @return the Senha_usuario
     */
    public String getSenha_usuario() {
        return Senha_usuario;
    }

    /**
     * @param Senha_usuario the Senha_usuario to set
     */
    public void setSenha_usuario(String Senha_usuario) {
        this.Senha_usuario = Senha_usuario;
    }

    public double getSaldo_conta() {
        return saldo_conta;
    }

    public void setSaldo_conta(double saldo_conta) {
        this.saldo_conta = saldo_conta;
    }

    public double getCredito_conta() {
        return credito_conta;
    }

    public void setCredito_conta(double credito_conta) {
        this.credito_conta = credito_conta;
    }
}
