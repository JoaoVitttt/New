package Conexao;

import CodPrograma.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Adm
 */
public class UsuarioConect {

    Connection in;
    PreparedStatement pscad;
    ResultSet Rs;

    public ResultSet authenticationUser(Usuario objUsuario) {
        in = new Conexao().conectaBD();

        try {
            String x = "select * from usuario where nome_usuario = ? and senha_usuario = ? ";

            PreparedStatement ps = in.prepareStatement(x);
            ps.setString(1, objUsuario.getNome_usuario());
            ps.setString(2, objUsuario.getSenha_usuario());

            ResultSet rs = ps.executeQuery();
            return rs;

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "UsuarioConect = authenticationUser " + e);
            return null;
        }
    }

    public void CadastrarUsuario(Usuario objuser) {
        String sql = "insert into usuario (nome_usuario, senha_usuario) values (?,?)";
        in = new Conexao().conectaBD();

        try {
            pscad = in.prepareStatement(sql);
            pscad.setString(1, objuser.getNome_usuario());
            pscad.setString(2, objuser.getSenha_usuario());

            pscad.execute();
            pscad.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "UsuarioConect = CadastrarUsuario " + e);
        }
    }

    ArrayList<Usuario> lista = new ArrayList<>();

    public ArrayList<Usuario> RsUsuario() {
        String y = "select * from usuario";
        in = new Conexao().conectaBD();
        try {
            pscad = in.prepareStatement(y);
            Rs = pscad.executeQuery();

            while (Rs.next()) {
                Usuario objusu = new Usuario();
                objusu.setId_usuario(Rs.getInt("id_usuario"));
                objusu.setNome_usuario(Rs.getString("nome_usuario"));
                objusu.setSenha_usuario(Rs.getString("senha_usuario"));

                lista.add(objusu);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "UsuarioConect = RsUsuario " + e);
        }
        return lista;
    }
    
    public void AlterarUsuario(Usuario objuser) {
        String sql = "update usuario set nome_usuario = ?, senha_usuario = ? where id_usuario = ?";
        in = new Conexao().conectaBD();

        try {
            pscad = in.prepareStatement(sql);
            pscad.setString(1, objuser.getNome_usuario());
            pscad.setString(2, objuser.getSenha_usuario());
            pscad.setInt(3, objuser.getId_usuario());

            pscad.execute();
            pscad.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "UsuarioConect = AlterarUsuario " + e);
        }
    }
    
    public void ExcluirUsuario(Usuario objuser) {
        String sql = "delete from usuario where id_usuario = ?";
        in = new Conexao().conectaBD();

        try {
            pscad = in.prepareStatement(sql);
            pscad.setInt(1, objuser.getId_usuario());

            pscad.execute();
            pscad.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "UsuarioConect = ExcluirUsuario " + e);
        }
    }
    
    //ArrayList<Usuario> lista = new ArrayList<>();

    public ArrayList<Usuario> SsUsuario() {
        String sql = "select * from usuario";
        in = new Conexao().conectaBD();
        try {
            pscad = in.prepareStatement(sql);
            Rs = pscad.executeQuery();

            while (Rs.next()) {
                Usuario objusu = new Usuario();
                objusu.setId_usuario(Rs.getInt("id_usuario"));
                objusu.setSaldo_conta(Rs.getDouble("Saldo_conta"));
                objusu.setCredito_conta(Rs.getDouble("Credito_conta"));

                lista.add(objusu);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "UsuarioConect = SsUsuario " + e);
        }
        return lista;
    }
    
    public void SacarUsuario(Usuario objuser) {
        String sql = "update usuario set saldo_conta = saldo_conta - ? where id_usuario = ?";
        in = new Conexao().conectaBD();

        try {
            pscad = in.prepareStatement(sql);
            pscad.setDouble(1, objuser.getSaldo_conta());
            pscad.setInt(2, objuser.getId_usuario());

            pscad.execute();
            pscad.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "UsuarioConect = SacarUsuario " + e);
        }
    }
    
    public void DepositarSaldo(Usuario objuser) {
        String sql = "update usuario set saldo_conta = saldo_conta + ? where id_usuario = ?";
        in = new Conexao().conectaBD();

        try {
            pscad = in.prepareStatement(sql);
            pscad.setDouble(1, objuser.getSaldo_conta());
            pscad.setInt(2, objuser.getId_usuario());

            pscad.execute();
            pscad.close();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "UsuarioConect = SacarUsuario " + e);
        }
    }
     
}
