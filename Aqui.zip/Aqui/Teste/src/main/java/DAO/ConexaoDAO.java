/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 *
 * @author Adm
 */
public class ConexaoDAO {
    public static void main(String[] args) throws SQLException {
        Connection con = null;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/banco", "usuario", "senha");
            ResultSet rsuser = con.createStatement().executeQuery("select * from usuario");
            while (rsuser.next()) {
                System.err.println("Nome: " + rsuser.getString("nome_usuario"));
            }
        } catch (Exception e) {
            System.out.println("Driver do banco de dados não localizado");
        } finally {
            if (con != null) {
                con.close();
            }
        }

    }
}

/*
public class Conexao {
    public Connection conectaBD(){
        Connection in = null;
        
        try {
            String url = "jdbc:postgresql://localhost:5432/banco?user=postgresql&password=postgresql";
            in = DriverManager.getConnection(url);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Conexao" + e.getMessage());
        }
        return in;
    }
}*/
