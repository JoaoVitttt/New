
package DAO;

/**
 *
 * @author Adm
 */
public class test {

    public static void main(String[] args) {
        // TODO code application logic here
        ConexaoDAO con = new ConexaoDAO();
       
    }
}
