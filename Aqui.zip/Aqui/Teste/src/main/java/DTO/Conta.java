/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

import Teste.User;
import Teste.Utils;

/**
 *
 * @author Adm
 */
public class Conta {
    private static int counter= 1;
    private int id_usuario;
    private User usuario;
    private double saldo_conta = 0.0;
    private double credito_conta = 500.0;
    
    public Conta(User usuario){
        this.id_usuario = Conta.counter;
        this.usuario = usuario;
        this.updateSaldo();
        Conta.counter += 1;       
    }

    public static int getCounter() {
        return counter;
    }

    public static void setCounter(int aCounter) {
        counter = aCounter;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public User getUsuario() {
        return usuario;
    }

    public void setUsuario(User usuario) {
        this.usuario = usuario;
    }

    public double getSaldo_conta() {
        return saldo_conta;
    }

    public void setSaldo_conta(double saldo_conta) {
        this.saldo_conta = saldo_conta;
    }

    public double getCredito_conta() {
        return credito_conta;
    }

    public void setCredito_conta(double credito_conta) {
        this.credito_conta = credito_conta;
    }
    
    public String toString() {

        return "\nBank account: " + this.getId_usuario() +
                "\nUsuario: " + this.usuario.getName() +
                "\nCredito: " + Utils.doubleToString(this.getCredito_conta()) +
                "\nSaldo: " + Utils.doubleToString(this.getSaldo_conta()) +
                "\n" ;
    }

    public void depositar(Double valor) {
        if(valor > 0) {
            setSaldo_conta(saldo_conta + valor);
            //this.saldo = this.getSaldo() + valor;
            System.out.println("Seu depósito foi realizado com sucesso!");
        }else {
            System.out.println("Não foi possível realizar o depósito!");
        }
    }

    public void sacar(Double valor) {
        if(valor > 0 && this.getSaldo_conta() >= valor) {
            setSaldo_conta(saldo_conta - valor);
            System.out.println("Saque realizado com sucesso!");
        }else {
            System.out.println("Não foi possível realizar o saque!");
        }
    }

    public void transferencia(Teste.Conta contaParaDeposito, Double valor) {
        if(valor > 0 && this.getSaldo_conta() >= valor) {
            setSaldo_conta(getSaldo_conta() - valor);
            //this.saldo = this.getSaldo() - valor;
            contaParaDeposito.saldo = contaParaDeposito.getSaldo() + valor;
            System.out.println("Transferência realizada com sucesso!");
        }else {
            System.out.println("Não foi possível realizar a tranferência");
        }

    }
}
